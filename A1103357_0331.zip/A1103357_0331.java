import java.util.*;

public class A1103357_0331_1{
    public static void main(String[] args) {
        animal.showinfo();

        animal animal1 = new animal("雪寶", 1.1, 52, 100);
        animal animal2 = new animal("驢子", 1.5, 99, 200);
        Human human1 = new Human("阿克", 1.9, 80, 150, "男");
        Human human2 = new Human("漢斯", 1.8, 78, 130, "男");
        Human human3 = new Human("安那", 1.7, 48, 120, "女"); 
        snow snow = new snow("愛沙", 1.7, 50, 120, "女", true);

        animal1.show();
        animal2.show();
        human1.show();
        human2.show();
        human3.show();
        snow.show();   

        Scanner sc = new Scanner(System.in);

        System.out.print("請輸入雪寶的時間與加速度(若無加速度則輸入0): ");
        int a1M = sc.nextInt();
        double a1A = sc.nextDouble();
        double a1D;
        if(a1A == 0){
            a1D = animal1.distance(a1M);
            System.out.println("雪寶奔跑的距離為"+a1D+"公尺");
        }else{
            a1D = animal1.distance(a1M, a1A);
            System.out.println("雪寶奔跑的距離為"+a1D+"公尺");
        }
        
        System.out.print("請輸入驢子的時間與加速度(若無加速度則輸入0): ");
        int a2M = sc.nextInt();
        double a2A = sc.nextDouble();
        double a2D;
        if(a2A == 0){
            a2D = animal2.distance(a2M);
            System.out.println("驢子奔跑的距離為"+a2D+"公尺");
        }else{
            a2D = animal2.distance(a2M, a2A);
            System.out.println("驢子奔跑的距離為"+a2D+"公尺");
        }

        System.out.print("請輸入阿克的時間與加速度(若無加速度則輸入0): ");
        int h1M = sc.nextInt();
        double h1A = sc.nextDouble();
        double h1D;
        if(h1A == 0){
            h1D = human1.distance(h1M);
            System.out.println("阿克奔跑的距離為"+h1D+"公尺");
        }else{
            h1D = human1.distance(h1M, h1A);
            System.out.println("阿克奔跑的距離為"+h1D+"公尺");
        }

        System.out.print("請輸入漢斯的時間與加速度(若無加速度則輸入0): ");
        int h2M = sc.nextInt();
        double h2A = sc.nextDouble();
        double h2D;
        if(h2A == 0){
            h2D = human2.distance(h2M);
            System.out.println("漢斯奔跑的距離為"+h2D+"公尺");
        }else{
            h2D = human2.distance(h2M, h2A);
            System.out.println("漢斯奔跑的距離為"+h2D+"公尺");
        }

        System.out.print("請輸入安那的時間與加速度(若無加速度則輸入0): ");
        int h3M = sc.nextInt();
        double h3A = sc.nextDouble();
        double h3D;
        if(h3A == 0){
            h3D = human3.distance(h3M);
            System.out.println("安那奔跑的距離為"+h3D+"公尺");
        }else{
            h3D = human3.distance(h3M, h3A);
            System.out.println("安那奔跑的距離為"+h3D+"公尺");
        }
        
        System.out.print("請輸入愛沙的時間與加速度(若無加速度則輸入0): ");
        int sM = sc.nextInt();
        double sA = sc.nextDouble();
        double sD;
        if(sA == 0){
            sD = snow.distance(sM);
            System.out.println("愛沙奔跑的距離為"+sD+"公尺");
        }else{
            sD = snow.distance(sM, sA);
            System.out.println("愛沙奔跑的距離為"+sD+"公尺");
        }
    }
}
public class animal{
    String name;
    double height;
    int weight;
    double speed;

    animal(String name, double height, int weight, double speed){
        this.name = name;
        this.height = height;
        this.weight = weight;
        this.speed = speed;
    }

    void show(){
        System.out.println("姓名: "+name+" 身高: "+height+"m 體重: "+weight+"kg 速度: "+speed+" m/60s");
    }

    double distance(int m, double a){
        double d = m * a * speed;
        return d;
    }
    double distance(int m){
        double d = m * speed;
        return d;
    }

    public static void showinfo(){
        System.out.println("歡迎進入冰雪奇緣系統");
    }
}

class Human extends animal{
    String gender;

    Human(String name, double height, int weight, double speed, String gender){
        super(name, height, weight, speed);
        this.gender = gender;
    }

    void show(){
        System.out.println("姓名: "+name+" 身高: "+height+"m 體重: "+weight+"kg 速度: "+speed+" m/60s 性別: "+gender);
    }
}

class snow extends Human{
    boolean frozen;
    String result;

    snow(String name, double height, int weight, double speed, String gender, boolean frozen){
        super(name, height, weight, speed, gender);
        result = frozen ? "Yes" : "No";
    }

    void show(){
        System.out.println("姓名: "+name+" 身高: "+height+"m 體重: "+weight+"kg 速度: "+speed+" m/60s 性別: "+gender+" 冰凍屬性: "+result);
    }

    double distance(int m, double a){
        double d = m * a * speed * 2;
        return d;
    }
    double distance(int m){
        double d = m * speed * 2;
        return d;
    }
}